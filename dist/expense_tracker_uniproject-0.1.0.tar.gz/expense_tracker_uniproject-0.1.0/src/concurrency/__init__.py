from .init_data import initialize_database

__all__ = ["initialize_database"]